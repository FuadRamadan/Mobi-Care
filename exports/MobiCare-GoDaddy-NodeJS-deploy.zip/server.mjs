import { createReadStream, existsSync, statSync } from "node:fs";
import { createServer, request as httpRequest } from "node:http";
import { spawn } from "node:child_process";
import { extname, join, normalize, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL(".", import.meta.url));
const publicPort = Number(process.env.PORT || 3000);
const apiPort = Number(process.env.INTERNAL_API_PORT || 3101);
if (!Number.isInteger(publicPort) || publicPort < 1) throw new Error("PORT must be a positive integer");

const api = spawn(process.execPath, [join(root, "api", "index.mjs")], {
  env: {
    ...process.env,
    PORT: String(apiPort),
    NODE_ENV: "production",
    SMS_TRANSPORT: process.env.SMS_TRANSPORT || "orange"
  },
  stdio: "inherit"
});
api.on("exit", (code, signal) => {
  console.error(`MobiCare API exited (${signal || code})`);
  process.exit(code || 1);
});

const mime = {
  ".css": "text/css; charset=utf-8", ".gif": "image/gif", ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon", ".jpeg": "image/jpeg", ".jpg": "image/jpeg", ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".map": "application/json; charset=utf-8", ".png": "image/png",
  ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8", ".webp": "image/webp", ".woff": "font/woff", ".woff2": "font/woff2"
};

function safeFile(base, pathname) {
  const candidate = resolve(base, "." + normalize("/" + pathname));
  if (candidate !== base && !candidate.startsWith(base + sep)) return null;
  if (!existsSync(candidate) || !statSync(candidate).isFile()) return null;
  return candidate;
}
function sendFile(req, res, file) {
  const headers = { "Content-Type": mime[extname(file).toLowerCase()] || "application/octet-stream" };
  if (file.includes(`${sep}assets${sep}`)) headers["Cache-Control"] = "public, max-age=31536000, immutable";
  else headers["Cache-Control"] = "no-cache";
  res.writeHead(200, headers);
  if (req.method === "HEAD") return res.end();
  createReadStream(file).pipe(res);
}
function proxyApi(req, res) {
  const headers = { ...req.headers, host: `127.0.0.1:${apiPort}`, "x-forwarded-host": req.headers.host || "", "x-forwarded-proto": "https" };
  const upstream = httpRequest({ hostname: "127.0.0.1", port: apiPort, method: req.method, path: req.url, headers }, upstreamRes => {
    res.writeHead(upstreamRes.statusCode || 502, upstreamRes.headers);
    upstreamRes.pipe(res);
  });
  upstream.on("error", error => {
    console.error("API proxy error", error.message);
    if (!res.headersSent) res.writeHead(503, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "API temporarily unavailable" }));
  });
  req.pipe(upstream);
}

const gatewayRoot = join(root, "public", "gateway");
const pharmacyRoot = join(root, "public", "pharmacy-portal");
const server = createServer((req, res) => {
  const pathname = new URL(req.url || "/", "http://localhost").pathname;
  if (pathname === "/api" || pathname.startsWith("/api/")) return proxyApi(req, res);
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { Allow: "GET, HEAD" }); return res.end("Method Not Allowed");
  }
  if (pathname === "/pharmacy-portal" || pathname.startsWith("/pharmacy-portal/")) {
    const relative = pathname.replace(/^\/pharmacy-portal\/?/, "");
    return sendFile(req, res, safeFile(pharmacyRoot, relative) || join(pharmacyRoot, "index.html"));
  }
  return sendFile(req, res, safeFile(gatewayRoot, pathname.slice(1)) || join(gatewayRoot, "index.html"));
});
server.listen(publicPort, "0.0.0.0", () => console.log(`MobiCare listening on ${publicPort}`));

function shutdown(signal) {
  server.close(() => process.exit(0));
  api.kill(signal);
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
