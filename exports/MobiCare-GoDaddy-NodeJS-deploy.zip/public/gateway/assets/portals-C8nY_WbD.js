const a={patient:{loginUrl:`${"/".replace(/\/$/,"")}/app`},pharmacy:{loginUrl:"/pharmacy-portal/"}},r="partners@mobicare.sl";export{a as P,r as a};
