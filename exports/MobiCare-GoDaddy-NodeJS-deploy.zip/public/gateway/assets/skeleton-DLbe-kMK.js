import{j as r,a as s}from"./index-CYtk5_TU.js";function t({className:a,...e}){return r.jsx("div",{className:s("animate-pulse rounded-md bg-primary/10",a),...e})}export{t as S};
