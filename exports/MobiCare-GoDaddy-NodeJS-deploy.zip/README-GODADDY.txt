MobiCare - GoDaddy Node.js Hosting Package
==========================================

Upload this ZIP using GoDaddy Node.js Hosting -> Upload ZIP -> Browse files -> Deploy.
Do not upload the complete backup ZIP; this package is the deployable one.

Required GoDaddy app secrets
----------------------------
DATABASE_URL       PostgreSQL connection URL after importing the provided database dump.
SESSION_SECRET     A new, long random production value (do not reuse a value posted in chat).
ALLOWED_ORIGINS    Final HTTPS origin(s), comma-separated, for example https://example.com.

PORT is supplied automatically by GoDaddy; do not add or hard-code it.
HQ_ADMIN_* secrets are only needed if rerunning the HQ bootstrap; the restored database already
contains the bootstrapped HQ account.

Database
--------
This deploy ZIP intentionally does not contain the database dump. Import
mobicare-development.sql from the complete backup into a PostgreSQL database, then configure
DATABASE_URL in GoDaddy Settings -> Secrets.

Routes
------
/                    MobiCare gateway, patient experience, and HQ login
/pharmacy-portal/    Pharmacy portal
/api/healthz         API health check

Portability limitation
----------------------
MobiCare image features currently use Replit App Storage. The web apps and database-backed
features can run on GoDaddy, but prescription, profile, team, and courier image operations need
an external object-storage configuration or a GoDaddy-specific storage adapter.

Security
--------
No .env file, Replit secret, database dump, or plaintext credential file is included.
